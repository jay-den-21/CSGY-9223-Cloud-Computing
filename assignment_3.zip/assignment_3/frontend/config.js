window.APP_CONFIG = Object.freeze({
  "API_BASE_URL": "https://udww739n7i.execute-api.us-east-1.amazonaws.com/prod",
  "API_KEY": "QugZbULipp75049wq6XDH5Do0v8NKmzh4rR9ri97"
});
